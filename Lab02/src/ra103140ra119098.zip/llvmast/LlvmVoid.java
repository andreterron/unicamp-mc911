package llvmast;
public class LlvmVoid extends LlvmType{}